#include "House.hpp"
#include "Pyramid.hpp"
#include "Cube.hpp"

House::House()
{
	// create new cube and pyramid objects
	cube = new Cube();
	cube->setParentMC(&mc);
	pyramid = new Pyramid();
	pyramid->setParentMC(&mc);

	//move pyramid above the cube to create the house
	pyramid->translate(0, 0, 1);
}

void House::draw()
{
    glPushMatrix();
    this->ctmMultiply();
    glScalef(s, s, s);

    //draw shapes
    cube->draw();
    pyramid->draw();
    glPopMatrix();
}
