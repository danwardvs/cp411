#include "Surface.hpp"

extern RenderMode renderMode;

Surface::Surface() {
	reset();
}

void Surface::reset() {
	row = 0;
	col = 0;
}

void Surface::drawSurface() {

	switch (renderMode) {
	case WIRE:
		for (int j = 0; j < col-1; j++) {
			for (int i = 0; i < row -1; i++) {
				glBegin(GL_LINE_LOOP);
					glVertex3f(Pts[i][j].x, Pts[i][j].y, Pts[i][j].z);
					glVertex3f(Pts[i+1][j].x, Pts[i+1][j].y, Pts[i+1][j].z);
					glVertex3f(Pts[i+1][j+1].x, Pts[i+1][j+1].y, Pts[i+1][j+1].z);
					glVertex3f(Pts[i][j+1].x, Pts[i][j+1].y, Pts[i][j+1].z);
				glEnd();
			}
		}
		break;
	case CONSTANT:
		for (int j = 0; j < col-1; j++) {
			for (int i = 0; i < row -1; i++) {
				glBegin(GL_POLYGON);
					glVertex3f(Pts[i][j].x, Pts[i][j].y, Pts[i][j].z);
					glVertex3f(Pts[i+1][j].x, Pts[i+1][j].y, Pts[i+1][j].z);
					glVertex3f(Pts[i+1][j+1].x, Pts[i+1][j+1].y, Pts[i+1][j+1].z);
					glVertex3f(Pts[i][j+1].x, Pts[i][j+1].y, Pts[i][j+1].z);
				glEnd();
			}
		}
		break;
	case FLAT:
		glShadeModel(GL_FLAT);
		glBegin(GL_POLYGON);
		for (int j = 0; j < col-1; j++) {
			for (int i = 0; i < row -1; i++) {
				glBegin(GL_POLYGON);
					glVertex3f(Pts[i][j].x, Pts[i][j].y, Pts[i][j].z);
					glVertex3f(Pts[i+1][j].x, Pts[i+1][j].y, Pts[i+1][j].z);
					glVertex3f(Pts[i+1][j+1].x, Pts[i+1][j+1].y, Pts[i+1][j+1].z);
					glVertex3f(Pts[i][j+1].x, Pts[i][j+1].y, Pts[i][j+1].z);
				glEnd();
			}
		}
		break;
	case SMOOTH:
		glEnable(GL_NORMALIZE);
		glShadeModel(GL_SMOOTH);
		glBegin(GL_POLYGON);
		for (int j = 0; j < col-1; j++) {
			for (int i = 0; i < row -1; i++) {
				glBegin(GL_POLYGON);
					glVertex3f(Pts[i][j].x, Pts[i][j].y, Pts[i][j].z);
					glVertex3f(Pts[i+1][j].x, Pts[i+1][j].y, Pts[i+1][j].z);
					glVertex3f(Pts[i+1][j+1].x, Pts[i+1][j+1].y, Pts[i+1][j+1].z);
					glVertex3f(Pts[i][j+1].x, Pts[i][j+1].y, Pts[i][j+1].z);
				glEnd();
			}
		}
		break;
	case PHONG:
		for (int i = 0; i < row-1; i++) {
			glBegin(GL_QUAD_STRIP);
			for (int j = 0; j < col; j++) {
				glNormal3f(Normal[i][j].x, Normal[i][j].y, Normal[i][j].z);
				glVertex3f(Pts[i][j].x, Pts[i][j].y, Pts[i][j].z);
				glNormal3f(Normal[i+1][j].x, Normal[i+1][j].y, Normal[i+1][j].z);
				glVertex3f(Pts[i + 1][j].x, Pts[i + 1][j].y, Pts[i + 1][j].z);
			}
			glEnd();
		}
		break;
	case TEXTURE:
		glColor3f(1, 1, 1);
		glPolygonMode( GL_FRONT, GL_FILL);
		glPolygonMode( GL_BACK, GL_LINE);
		glEnable(GL_TEXTURE_2D);
		glBindTexture(GL_TEXTURE_2D, 2);

		GLfloat sx = 1.0/col;
		GLfloat sy = 1.0/row;

		for (int i= 0; i < row-1; i++) {
			glBegin(GL_QUAD_STRIP);
			for (int j=0; j < col; j++) {
				glNormal3f(Normal[i][j].x, Normal[i][j].y, Normal[i][j].z);
				glTexCoord2f(i*sx, j*sy);
				glVertex3f(Pts[i][j].x, Pts[i][j].y, Pts[i][j].z);

				glNormal3f(Normal[i+1][j].x, Normal[i+1][j].y, Normal[i+1][j].z);
				glTexCoord2f((i+1)* sx, j * sy);
				glVertex3f(Pts[i + 1][j].x, Pts[i + 1][j].y, Pts[i + 1][j].z);
			}
			glEnd();
		}
		glDisable(GL_TEXTURE_2D);
		break;
	}
}

void Surface::draw() {
	glPushMatrix();
	ctmMultiply();
	glScalef(s * 0.01, s * 0.01, s * 0.01);		// to shrink the object to size of viewable
	drawSurface();
	glPopMatrix();
}

