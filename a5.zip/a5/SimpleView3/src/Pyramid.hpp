/*
 * Description: SimpleView reference design
 * Author: HBF
 * Version: 2022-10-03
 */
#ifndef CPYRAMID_H
#define CPYRAMID_H

#include <GL/glut.h>
#include "Shape.hpp"
#include "Vector.hpp"

#include "Camera.hpp"
#include "Light.hpp"

class Pyramid: public Shape {
protected:
	GLfloat vertex[5][3];  /* 2D array to store cube vertices */
	GLint face[4][3];      /* 2D array to store faces */
	GLfloat r, g, b;       /* color pyramid */

	/* SimpleView2 properties */
	GLfloat faceColor[4][3];
	GLfloat faceNormal[4][3];
	GLfloat vertexColor[5][3];
	GLfloat vertexNormal[5][3];
public:
	Pyramid();
	void draw();
	void drawFace(int);

	/* SimpleView2 properties */
	bool isFrontface(int faceindex, Camera camera);
	GLfloat getFaceShade(int faceindex, Light light);
	GLfloat getVertexShade(int vertexindex, Light light);
};

#endif
