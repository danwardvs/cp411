# A5 Report

Author: Bryan Gadd

Date: November 24th, 2022

Check [readme.txt](readme.txt) for course work statement and self-evaluation. 


## Q1 Curve and surface computing (short_answer)


### Q1.1 Cubic spline computing
![Hermit Cubic Splice](images/a5q1.1.png){width=90%}


### Q1.2 Rotation surface and normal
![Hermit Cubic Splice](images/a5q1.2.png){width=90%}


## Q2 Curve, surface, texture, GLSL (lab practice)


### Q2.1 Curve model and rendering 
Complete? Yes

![Curves](images/curves.png){width=90%}


### Q2.2 Surface model and rendering 
Complete? Yes

![Surface](images/surface.png){width=90%}


### Q2.3 Texture mapping 
Complete? Yes

![Texture](images/texture.png){width=90%}


### Q2.4 GPU programming by GLSL 
Complete? Yes

![GLSL](images/glsl.png){width=90%}

![Fractal](images/fractal.png){width=90%}


## Q3 SimpleView3 - texture, GLSL, curve, and surface (programming)


### Q3.1 Texture mapping basics 

Complete? Yes

![Texture](images/simpleview_texture.png){width=90%}


### Q3.2 Solar system with texture mapping 

Complete? Yes

![Solar System](images/simpleview_solar_system.png){width=90%}


### Q3.3 Bezier curve -Take picture of this then Rotation surface.

Complete? Yes

![Bezier Curve](images/simpleview_bezier.png){width=90%}


### Q3.4 Rotation surface of Bezier curve 

Complete? Yes

![Rotation Surface](images/simpleview_rotation_surface.png){width=90%}


### Q3.5 Phong shading by GLSL 

Complete? Yes

![Phong Shading](images/simpleview_phong_shading.png){width=90%}


### Q3.6 My Graphics Library 

Complete? No

If No, add a short description to describe the issues encountered.
Didn't have enough time to do it.




**References**

1. CP411 a5
