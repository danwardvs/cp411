## Simple texture and sound example

1. Import into Eclipse as project archieve
2. Compile and run. Right click mouse to bring up menu. Use R or L key to rotate the object.
3. Start/stop playing sound. 
