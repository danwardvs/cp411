Name: Daniel Van Stemp
ID: 181549810
Email: vans9810@mylaurier.ca
WorkID: cp411-a2
Statement: I claim that the enclosed submission is my individual work.

Fill in the self-evaluation in the following evaluation grid.
Symbols:  A - Assignment, Q - Question, T - Task
Field format: [self-evaluation/total marks/marker's evaluation]

For example, you put your self-evaluation, say 2, like [2/2/*]. 
If markers give different evaluation value, say 1, it will show 
[2/2/1] in the marking report. 

Question_ID [self-evaluation/total/marker-evaluation] Description

A2

Q1 Graphics pipeline
Q1.1 [4/4/*] Primitives                              
Q1.2 [3/3/*] Coordinate systems & transformations    
Q1.3 [3/3/*] Scan conversion                         
Q2 OpenGL and Glut
Q2.1 [4/4/*] OpenGL primitives                       
Q2.2 [4/3/*] Interactive graphics                    
Q2.3 [4/3/*] Bitmap file I/O                         
Q3 SimpleDraw
Q3.1 [10/10/*] Display window and menu                 
Q3.2 [10/10/*] Data structures                         
Q3.3 [5/5/*] Draw rectangles                         
Q3.4 [10/10/*] Draw circles                            
Q3.5 [20/20/*] Edit features                           
Q3.6 [10/10/*] Save/Open SVG files                     
Q3.7 [5/5/*] Export to bitmap                        
Q3.8 [10/10/*] Circle&Square artwork                   

Total: [100/100/*]


